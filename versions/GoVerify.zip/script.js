let button = document.getElementById('test');
button.onclick = () => {
    let g =new Goverify();
    g.test();
}

class Goverify{
constructor(args){
let data = '';
try{
data = 'one';
}catch(e){
data = 'broken';
}
}

test(){
let target = document.getElementById('search-query').value;
let depts = 'eskom.co.za,daff.gov.za,dac.gov.za,education.gov.za,policesecretariat.gov.za,doc.gov.za,cogta.gov.zasites/cogtapub,dcs.gov.za,dod.mil.za,economic.gov.za,energy.gov.za,environment.gov.za,gcis.gov.za,doh.gov.za,dhet.gov.za,home-affairs.gov.za,dhs.gov.za,ipid.gov.za,dirco.gov.za,justice.gov.za,labour.gov.zaDOL/,dmv.gov.za,dmr.gov.za,treasury.gov.za,thensg.gov.za,treasury.gov.za,judiciary.org.za,thepresidency-dpme.gov.za,dpe.gov.za,dpsa.gov.za,psc.gov.za,publicworks.gov.za,ruraldevelopment.gov.za,dst.gov.za,dsd.gov.za,saps.gov.za,sars.gov.za,dsbd.gov.za,ssa.gov.za,srsa.gov.za,statssa.gov.za,dtps.gov.za,tourism.gov.za,thedti.gov.za,dta.gov.za,transport.gov.za,dwa.gov.za,wcpd.gov.za,thepresidency.gov.za';
let depts_array = depts.split(',');
if(depts_array.indexOf(target.split('@')[1]) > -1){
document.getElementById('vnv').setAttribute('src', 'valid.png');
}else{
document.getElementById('vnv').setAttribute('src', 'invalid.png');
}
}
}

let g = new Goverify();